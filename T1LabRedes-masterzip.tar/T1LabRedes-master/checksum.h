/* Checksum declaration
 * shadows@whitefang.com
 */

#ifndef CHECKSUM_HEADER
#define CHECKSUM_HEADER

unsigned short in_cksum(unsigned short *addr,int len);

#endif
